<?php

if (! defined('MOLLIE_PAYMENT_METHOD_NAME')) {
    define('MOLLIE_PAYMENT_METHOD_NAME', 'mollie');
}
